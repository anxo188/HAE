// Lcd pinout settings
sbit LCD_RS at RB2_bit;
sbit LCD_EN at RB3_bit;
sbit LCD_D7 at RB7_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D4 at RB4_bit;
// Pin direction
sbit LCD_RS_Direction at TRISB2_bit;
sbit LCD_EN_Direction at TRISB3_bit;
sbit LCD_D7_Direction at TRISB7_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB4_bit;

//Variables Globales
unsigned short int contador = 0;
float temperatura; //Variable que almacena la temperatura recibida
unsigned short int *puntero; //Puntero utilizado para recorrer la memoria en bloques de 8 bits y almacenar los datos recibidos por UART
char txt[14]; //Variable auxiliar utilizada para representar valores por el LCD



void interrupt(){ /* Rutina de Control de Interrupciones */
    if(PIR1.RCIF){ // - Receive Interrupt -
          *(puntero+contador)=UART1_READ(); //Lectura de los datos recibidos por UART y almacenamiento en la posicion de memoria indicada por el puntero
          contador++; //Incremento del contador para desplazar el puntero 8 bits en memoria
          if(contador==4){ //Finalizacion de la recepcion de un bloque de 32 bits (float)
              Lcd_Cmd(_LCD_CLEAR); //Proceso de visualizacion por LCD
              FloatToStr(temperatura,txt);
              lcd_out(1,1,txt);
              Lcd_Chr_cp(223);
              Lcd_Chr_cp('C');
              Lcd_Cmd(_LCD_CURSOR_OFF);
              contador=0; //Se restaura el contador para recibir el siguiente bloque de datos
          }
          PIR1.RCIF=0; // Receive Interrupt Enable Flag
    }
}



void main() { /* Programa Principal */
      ADCON1 = 0x0F; //Terminales AN como E/S Digital
      CMCON = 0X07; //Comparadores Analogicos Off

      puntero = &temperatura; //Se coloca el puntero apuntando a la direccion de memoria donde comienza la variable que almacena la temperatura

      Lcd_Init(); //Encendido del LCD

      //Configuracion de Interrupciones
      PIR1.RCIF = 0; //Receive Interrupt Flag
      PIE1.RCIE = 1; //Receive Interrupt Enable
      INTCON.PEIE = 1; //Peripheral Interrupt Enable
      INTCON.GIE = 1; //Global Interrupt Enable

      UART1_Init(9600); //Encendido del canal de comunicacion UART
      delay_ms(300);

while(1){ //Bucle Infinito
asm nop;
}
}
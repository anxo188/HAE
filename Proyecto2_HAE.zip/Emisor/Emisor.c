float datos; //Variable que almacena los datos en crudo de la conversion A/D procedente del sensor de temperatura
float temperatura; //Variable en la que se almacena la temperatura medida
unsigned short int *puntero; //Puntero utilizado para recorrer la zona de memoria de la variable temperatura en bloques de 8 bits


void interrupt(){ /* Rutina de Control de Interrupciones */
if(INTCON.TMR0IE && INTCON.TMR0IF){ // - TIMER0 Interrupt -
TMR0H = (18661>>8); //Se restaura el valor de Alpha
TMR0L = 18661;
ADCON0.GO = 1; //A/D Converter Go
INTCON.TMR0IF = 0; //Desactiva el Flag del TIMER0
}
if(PIR1.ADIE && PIR1.ADIF){ // - A/D Converter Interrupt -
datos = ADRESL + (ADRESH << 8); //Lectura de los datos de la conversion A/D
temperatura = (datos * 5.0 )/1023.0; //Conversion de los datos obtenidos a Temperatura en grados Celsius
temperatura = 100.0*(temperatura - 0.5);

puntero = &temperatura; //Env�o mediante protocolo UART (Paquetes de 8 bits)
UART1_Write(*puntero);
delay_ms(10);
UART1_Write(*(puntero+1));
delay_ms(10);
UART1_Write(*(puntero+2));
delay_ms(10);
UART1_Write(*(puntero+3));
delay_ms(10);
PIR1.ADIF = 0; //Desactiva el A/D Converter Flag
}
}

void main(){
T0CON = 0X85; //Configuracion del TIMER0 para contar 1'5[s]
TMR0H = (18661>>8); //Valor de Alpha
TMR0L = 18661;

ADCON1 = 0x00; //Configuracion A/D Converter
ADCON0 = 0x03;
ADCON2 = 0x8D;

UART1_Init(9600); //Encendido del canal UART
delay_ms(300);

//Configuracion de Interrupciones
INTCON.TMR0IF = 0; //TIMER0 Interrupt Flag
INTCON.TMR0IE = 1; //TIMER0 Interrupt Enable
PIR1.ADIF = 0; //A/D Converter Interrupt Flag
PIE1.ADIE = 1; //A/D Converter Interrupt Enable
INTCON.PEIE = 1; //Peripheral Interrupt Enable
INTCON.GIE = 1; //Global Interrupt Enable

ADCON0.GO = 1; //A/D Converter Go

while(1){
 asm nop;
}
}
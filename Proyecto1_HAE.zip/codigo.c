/*

	Estado:
		0 Completamente Cerrada ;
		1 Cerrando ;
		2 Completamente Abierta ;
		3 Abriendo ;

	RB0 -> Cerrada
	RB1 -> Abierta
	RB2 -> Presencia
*/

short int estado = 0;//Comienza la puerta  completamente cerrada

void interrupt()
{
	if (PIR1.TMR1IF && PIE1.TMR1IE)
	{
		INTCON.TMR1IF = 0;//Pongo a 0 el flag de interrupcion
		//Reseteo el valor inicial (alfa) del ‘timer’
		TMR1H = (15536 >> 8); //Primero los bits altos
		TMR1L = (15536);//Despues los bits bajos

		//Se comprueba en que estado se encuentra el sistema, se supone no puede estar en 2 estados simultáneamente
		if (PORTB.B0 && !PORTB.B2)//Está completamente cerrada y no hay presencia, consecuencia se mantiene cerrada la puerta
		{
			//Motores
			PORTC.B0 = 0;
			PORTC.B1 = 0;
			//Cambio estado interno
			estado = 0;
			PORTD = 0;
		}
		else if (PORTB.B0 && PORTB.B2)//Está completamente cerrada y hay presencia, consecuencia se abre la puerta
		{
			//Motores
			PORTC.B0 = 1;
			PORTC.B1 = 0;
			estado = 3;
			PORTD = 0x03;
		}
		else if (PORTB.B1 && PORTB.B2)//Esta completamente abierta y hay presencia, consecuencia se mantiene abierta
		{
			PORTC.B0 = 0;
			PORTC.B1 = 0;
			estado = 2;
			PORTD = 0x02;
		}
		else if (PORTB.B1 && !PORTB.B2)//Esta completamente abierta y hay presencia, consecuencia se cierra
		{
			PORTC.B0 = 0;
			PORTC.B1 = 1;
			estado = 1;
			PORTD = 0x01;
		}
		else if (estado == 3 && !PORTB.B2)//Esta abriendose y deja de detectar presencia, consecuencia se cierra
		{

			PORTC.B0 = 0;
			PORTC.B1 = 0;
			T0CON.B7 = 1;//hay que añadir un delay porque en la vida real un motor cascaría con un cambio de sentido inmediato

		}
		else if (estado == 1 && !PORTB.B2)//Esta cerrandose y  no detecta presencia, consecuencia sigue cerrándose
		{

			PORTC.B0 = 0;
			PORTC.B1 = 1;
			estado = 1;
			PORTD = 0x01;
		}
		else if (estado == 3 && PORTB.B2)//Esta abriendose y  detecta presencia, consecuencia continua abriendose
		{
			PORTC.B0 = 1;
			PORTC.B1 = 0;
			estado = 3;
			PORTD = 0x03;
		}
		else if (estado == 1 && PORTB.B2)//Esta cerrandose y  detecta presencia, consecuencia empieza a abrirse
		{

			PORTC.B0 = 0;
			PORTC.B1 = 0;
			T0CON.B7 = 1;//hay que añadir un delay porque en la vida real un motor cascaría con un cambio de sentido inmediato

		}
	}
	if (INTCON.TMR0IF)
	{
		PORTD.B4 = 1;
		if (estado == 1) {
			PORTC.B0 = 0;
			PORTC.B1 = 1;
			estado = 3;
			PORTD = 0x03;
		}
		else {
			PORTC.B0 = 1;
			PORTC.B1 = 0;
			estado = 1;
			PORTD = 0x01;
		}

		INTCON.TMR0IF = 0;//Pongo a 0 el flag de interrupcion
	  //Reseteo el valor inicial (alfa) del ‘timer’
		TMR0H = (18661 >> 8); //Primero los bits altos
		TMR0L = (18661);//Despues los bits bajos
		PORTD.B4 = 1;
		T0CON.B7 = 0;
	}
}

void main()
{
	TRISC = 0;
	TRISB = 0x07;
	TRISD = 0;//Mostrar el estado de forma visual

	//Configuracion del timer 1 para 0.1 s
	T1CON = 0x81;//Prescaler de 4
	PIR1.TMR1IF = 0; // se pone el flag a 0
	PIE1.TMR1IE = 1; // se habilita la interrupción del Timer 0
	//se carga el valor inicial (alfa) del ‘contador’
	TMR1H = (15536 >> 8); //Primero los bits altos
	TMR1L = (15536);//Despues los bits bajos

//Configuracion del timer 0 para 1 s
	//Configuracion del timer
	T0CON = 0x85;//Prescaler de 64
	INTCON.TMR0IF = 0; // se pone el flag a 0
	//se carga el valor inicial (alfa) del ‘contador’
	TMR0H = (18661 >> 8); //Primero los bits altos
	TMR0L = (18661);//Despues los bits bajos
	INTCON.TMR0IE = 1;

	//Activo interrupciones
	INTCON.PEIE = 1;
	INTCON.GIE = 1;
	while (1);
}